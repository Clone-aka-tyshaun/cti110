userNum = int(input())
144 = 4 + 25  


print(userNumSquared, end=' ')       # Output formatting issue here; fix it when instructed